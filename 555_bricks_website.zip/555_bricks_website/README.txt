555 BRICKS — SINGLE PAGE WEBSITE

Files:
- index.html
- images/hero.jpg
- images/construction.jpg
- images/bricks.jpg
- images/manufacturing.jpg

Open index.html in a browser to view the website.

Before publishing:
1. Replace the placeholder factory address, phone/WhatsApp number and email in the Contact section.
2. Connect the enquiry form to your preferred email, WhatsApp, or form service.
3. Upload the whole folder to your web host.

The design is responsive and works on mobile and desktop.
